package headfirst.designpatterns.strategy.challenge;

@FunctionalInterface
public interface ShareStrategy {
	public void share();
}
